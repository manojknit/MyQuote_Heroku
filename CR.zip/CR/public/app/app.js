
angular
    .module('myApp', [])
    .controller('myController',function($scope, $http) {
        $scope.msg = "Hello World";
    });