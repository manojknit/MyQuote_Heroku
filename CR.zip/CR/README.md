# MeanStarter
Mean Stack Starter

You should have MongoDb service running on your server.

Then do a 'npm install' and 'npm start'.